package base;

//Interface for all the games
public interface Playable {
    public void play();
}
