package base;

//Interface for all the game output classes
public interface GameOutput {
    public String greetPlayer();
    public String showRules();
    public String requestInput();
}
